#!/usr/bin/env python3
"""Rebuild PR #394 charts from the bundled, immutable evidence snapshot.

Usage: python plot_curves.py
Dependencies: matplotlib, numpy (no accelerator or network required).
Optional: H3_PLOT_FONT=/path/to/a/Chinese/font.ttf
"""
import csv
import hashlib
import json
import os
from pathlib import Path
from statistics import median

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
import numpy as np

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source"
META = json.loads((ROOT / "source-metadata.json").read_text())
SHA = META["pr_head"]
URL = f"https://github.com/InferMatrixLab/InferRSI/blob/{SHA}/evidence/h3-image-ascend/"


def read(path):
    return json.loads((SOURCE / path).read_text())


PLAN = read("plan/workload.json")
WORKLOADS = {w["id"]: w for w in PLAN["workloads"]}
COLORS = {"W1": "#2763c6", "W2": "#0e897e", "W3": "#9163bc"}
INK, MUTED, GRID, RED = "#182b45", "#64748b", "#e8edf3", "#c14445"
TITLES = {"W1": "W1  Text-to-image | 4736 × 3552", "W2": "W2  Text-to-image | 1024 × 1024", "W3": "W3  Image editing | 1024 × 1024"}
font_path = os.environ.get("H3_PLOT_FONT", "/usr/share/fonts/google-droid-fonts/DroidSansFallback.ttf")
if Path(font_path).exists():
    font_manager.fontManager.addfont(font_path)
    chinese_font = font_manager.FontProperties(fname=font_path).get_name()
else:
    chinese_font = "sans-serif"
plt.rcParams.update({
    "font.family": ["DejaVu Sans", chinese_font], "font.size": 11,
    "text.color": INK, "axes.labelcolor": MUTED, "xtick.color": MUTED,
    "ytick.color": MUTED, "axes.edgecolor": "#d8e1eb",
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.unicode_minus": False, "svg.fonttype": "path",
    "pdf.fonttype": 42, "figure.facecolor": "white", "axes.facecolor": "white",
})

rows = []


def extract(path, group, label, revision, arm="configuration", nested=False, quality="see_source"):
    data = read(path)
    metrics = data["latency"][arm] if nested else data["workloads"]
    if not nested:
        assert data.get("quality_run") is False, path
        assert data.get("error") is None, path
        assert data["requests"] == data["expected_requests"] == 12, path
    for w, values in metrics.items():
        samples = values["samples_s"]
        assert len(samples) == 3, (path, w)
        assert abs(median(samples) - values["median_s"]) < 1e-10, (path, w)
        assert values["target_s"] == WORKLOADS[w]["target_s"]
        assert values["target_met"] == (values["median_s"] <= values["target_s"])
        rows.append({
            "group": group, "configuration": label, "arm": arm, "workload": w,
            "engine_base_or_revision": revision, "median_s": values["median_s"],
            "sample_min_s": min(samples), "sample_max_s": max(samples),
            "sample_1_s": samples[0], "sample_2_s": samples[1], "sample_3_s": samples[2],
            "target_s": values["target_s"], "quality_scope": quality,
            "campaign_verdict": "INCONCLUSIVE", "source_path": path,
            "source_url": URL + path,
        })
    return metrics


STAGES = [
    (0, "TP4\ndeterministic", "deterministic-control-tp4", "historical", "9bbff156d", "control"),
    (1, "SP4\nAdaLN staging", "native-sp4-offload", "historical", "9bbff156d", "control"),
    (2, "SP4\nVAE4 graphs", "sp4-vae4", "historical", "9bbff156d", "exact_RGB"),
    (3, "SP4\nVAE batch8", "sp4-vaebatch8", "historical", "9bbff156d", "numerical_screen_PASS"),
    (4, "SP4\nbatch32 + FP16 enc", "sp4-vae-batched-both", "historical", "9bbff156d", "numerical_screen_PASS"),
    (6, "SP4\nnative control", "submission-control-sp4", "submission", "ad37f7f", "control"),
    (7, "SP4\nbatched candidate", "submission-vae-batched", "submission", "ad37f7f", "numerical_screen_PASS"),
    (9, "SP4\nnative control", "round2-images/control-summary.json", "round2", "ad37f7f", "control"),
    (10, "SP4\nbatched candidate", "round2-images/candidate-summary.json", "round2", "ad37f7f", "numerical_screen_PASS"),
]
stage_metrics = []
for x, label, filename, group, revision, quality in STAGES:
    path = "results/" + (filename if filename.endswith(".json") else filename + "/summary.json")
    stage_metrics.append(extract(path, group, label.replace("\n", " "), revision, quality=quality))

ROUNDS = [
    (4, "All-MLP NZ", "mlp-nz-round4", False, "ad37f7f", "numerical_screen_FAIL"),
    (5, "Main-block NZ", "mlp-nz-round5", False, "ad37f7f", "numerical_screen_FAIL"),
    (6, "FP16 VAE decode", "vae-fp16-round6", False, "ad37f7f", "numerical_screen_PASS"),
    (12, "Prepared rows", "prepared-rows-round12-rejection.json", True, "ad37f7f", "exact_RGB_30_of_30"),
    (13, "Prepared text", "prepared-text-round13-result.json", True, "7f8395fed", "exact_RGB_30_of_30"),
    (16, "Post-load NZ", "postload-nz-round16-result.json", True, "7f8395fed", "exact_RGB_30_of_30"),
    (19, "Final-step FIA", "fia-final-step-round19-result.json", True, "7f8395fed", "numerical_screen_PASS"),
]
round_metrics = []
for number, label, filename, nested, revision, quality in ROUNDS:
    arms = {}
    for arm in ["control", "candidate"]:
        path = "results/" + (filename if nested else f"{filename}/{arm}-summary.json")
        arms[arm] = extract(path, "followup", f"R{number} {label}", revision, arm, nested,
                            quality if arm == "candidate" else "matched_control")
    round_metrics.append(arms)


def frame(ax):
    ax.set_axisbelow(True)
    ax.grid(axis="y", color=GRID, linewidth=0.9)
    ax.tick_params(axis="both", length=0, pad=7)
    ax.set_ylabel("HTTP latency (s)", fontsize=10, labelpad=12)


def save(fig, name):
    for extension in ["png", "svg", "pdf"]:
        fig.savefig(ROOT / f"{name}.{extension}", dpi=200, facecolor="white")
    plt.close(fig)


def main_curve():
    fig, axes = plt.subplots(3, 1, figsize=(16, 11), sharex=True)
    fig.subplots_adjust(left=0.075, right=0.965, top=0.815, bottom=0.205, hspace=0.43)
    fig.text(0.075, 0.956, "MiniMax-H3-Image | Optimization history", fontsize=23, weight="bold")
    fig.text(0.075, 0.918, "4 × Ascend 910B1 | Concurrency 1 · 6 steps · 1 warmup + 3 timed requests | Lower is better", fontsize=12, color=MUTED)
    fig.text(0.965, 0.958, "InferRSI  PR #394", ha="right", fontsize=13, color=MUTED)
    fig.text(0.965, 0.922, "INCONCLUSIVE · All targets unmet", ha="right", fontsize=11, color=RED)
    groups = [(range(5), "Historical configurations · base 9bbff156d", "#f5f7fa"),
              (range(5, 7), "Submission smoke · ad37f7f", "#f0f5fc"),
              (range(7, 9), "Round 2 repeat · ad37f7f", "#eff8f5")]
    for ax, w in zip(axes, WORKLOADS):
        frame(ax)
        color = COLORS[w]
        for indices, group_title, shade in groups:
            xs = [STAGES[i][0] for i in indices]
            vals = [stage_metrics[i][w] for i in indices]
            ys = [v["median_s"] for v in vals]
            errors = np.array([[y - min(v["samples_s"]) for y, v in zip(ys, vals)],
                               [max(v["samples_s"]) - y for y, v in zip(ys, vals)]])
            ax.axvspan(min(xs) - 0.38, max(xs) + 0.38, color=shade, zorder=0)
            ax.errorbar(xs, ys, yerr=errors, color=color, linewidth=2.1, marker="o", markersize=6,
                        capsize=4, elinewidth=1.2, zorder=3)
            for x, y in zip(xs, ys):
                ax.annotate(f"{y:.3f}", (x, y), xytext=(0, 12), textcoords="offset points",
                            ha="center", fontsize=10, color=color)
            if ax is axes[0]:
                ax.text(np.mean(xs), 1.28, group_title, transform=ax.get_xaxis_transform(),
                        ha="center", fontsize=11, color=MUTED)
        target = WORKLOADS[w]["target_s"]
        ax.axhline(target, color=RED, linestyle=(0, (5, 4)), linewidth=1.2)
        ax.text(10.45, target, f"Target {target:.2f}s", va="bottom", ha="right", fontsize=10,
                color=RED, bbox={"facecolor": "white", "edgecolor": "none", "pad": 2})
        top = max(max(m[w]["samples_s"]) for m in stage_metrics) * 1.19
        ax.set_ylim(0, top)
        ax.set_xlim(-0.5, 10.5)
        ax.set_title(TITLES[w], loc="left", fontsize=12, pad=10, color=color)
        control = stage_metrics[7][w]["median_s"]
        candidate = stage_metrics[8][w]["median_s"]
        ax.text(1, 1.08, f"R2 observed reduction {(1-candidate/control)*100:.1f}%  ·  {control/candidate:.2f}×",
                transform=ax.transAxes, ha="right", fontsize=11, color=color)
    axes[-1].set_xticks([s[0] for s in STAGES], [s[1] for s in STAGES], fontsize=10)
    fig.text(0.075, 0.122, "Points: median of 3 requests. Error bars: observed min/max, not confidence intervals. Lines break across revisions and launch pairs.", fontsize=9, color=MUTED)
    fig.text(0.075, 0.091, "Graph on/off also changed internal-format settings; the difference cannot be attributed to VAE alone. CPU checks overlapped the smoke runs.", fontsize=9, color=MUTED)
    fig.text(0.075, 0.060, "Batched candidates passed local numerical screens. Full visual acceptance and final ABBA remain incomplete; these are exploratory observations.", fontsize=9, color=MUTED)
    fig.text(0.075, 0.026, f"Source: github.com/InferMatrixLab/InferRSI/pull/394 · snapshot {SHA[:7]}  ·  2026-11-12  ·  Per-point provenance: curve-data.csv", fontsize=9, color=MUTED)
    save(fig, "optimization_curve")


def followup_curve():
    fig, axes = plt.subplots(3, 1, figsize=(16, 11), sharex=True)
    fig.subplots_adjust(left=0.075, right=0.965, top=0.785, bottom=0.205, hspace=0.45)
    fig.text(0.075, 0.956, "Follow-up iterations | Matched controls and candidates", fontsize=23, weight="bold")
    fig.text(0.075, 0.918, "7 completed timing comparisons from rounds 4–19 | Median of 3 requests; bars show min/max | Lower is better", fontsize=12, color=MUTED)
    fig.text(0.965, 0.958, "No follow-up candidate adopted", ha="right", fontsize=13, color=RED)
    handles = [Line2D([0], [0], color="#8a97a8", ls="--", marker="s", label="Matched control"),
               Line2D([0], [0], color=INK, ls="none", marker="o", markerfacecolor="white", label="Candidate: numerical screen passed"),
               Line2D([0], [0], color=RED, ls="none", marker="x", markersize=8, label="Candidate: numerical screen failed"),
               Line2D([0], [0], color=RED, ls="--", label="Frozen target")]
    fig.legend(handles=handles, loc="upper left", bbox_to_anchor=(0.068, 0.887), ncol=4, frameon=False, fontsize=11)
    for ax, w in zip(axes, WORKLOADS):
        frame(ax)
        color = COLORS[w]
        target = WORKLOADS[w]["target_s"]
        ax.axvspan(-0.4, 1.4, color="#fff2f1", zorder=0)
        ax.axvline(3.5, color="#c4cdd8", ls=":", linewidth=1.2)
        # Link controls only within each engine revision; candidates are independent experiments.
        for xs in [[0, 1, 2, 3], [4, 5, 6]]:
            ys = [round_metrics[i]["control"][w]["median_s"] for i in xs]
            ax.plot(np.array(xs)-0.06, ys, ls="--", color="#8a97a8", lw=1.4, zorder=2)
        for i, arms in enumerate(round_metrics):
            for arm, offset in [("control", -0.06), ("candidate", 0.06)]:
                v = arms[arm][w]
                y = v["median_s"]
                failed = arm == "candidate" and i in (0, 1)
                c = "#8a97a8" if arm == "control" else (RED if failed else color)
                marker = "s" if arm == "control" else ("x" if failed else "o")
                ax.errorbar(i+offset, y, yerr=[[y-min(v["samples_s"])], [max(v["samples_s"])-y]],
                            fmt=marker, color=c, markerfacecolor="white", markeredgewidth=1.7,
                            markersize=6, capsize=3, elinewidth=1.1, zorder=4)
            candidate = arms["candidate"][w]["median_s"]
            control = arms["control"][w]["median_s"]
            delta = (candidate/control-1)*100
            ax.text(i, 0.91, f"{delta:+.1f}%", transform=ax.get_xaxis_transform(), ha="center",
                    color=RED if i < 2 else color, fontsize=11)
        ax.set_title(TITLES[w], loc="left", fontsize=12, pad=10, color=color)
        ax.axhline(target, color=RED, ls=(0, (5, 4)), lw=1.2)
        ax.text(6.45, target, f"Target {target:.2f}s", ha="right", va="bottom", color=RED,
                fontsize=10, bbox={"facecolor": "white", "edgecolor": "none", "pad": 2})
        all_samples = [v for m in round_metrics for a in ("control", "candidate") for v in m[a][w]["samples_s"]]
        low = target * 0.90
        high = max(all_samples) + (max(all_samples)-low)*0.30
        ax.set_ylim(low, high)
        ax.set_xlim(-0.45, 6.45)
    axes[-1].set_xticks(range(len(ROUNDS)), [f"R{r[0]}\n{r[1]}" for r in ROUNDS], fontsize=11)
    fig.text(0.075, 0.128, "Percent change = candidate / matched control - 1; negative is faster. Candidates are independent trials, not cumulative changes. Y-axes are zoomed.", fontsize=9, color=MUTED)
    fig.text(0.075, 0.096, "R4–R12: base ad37f7f. R13 onward: base 7f8395fed (vertical divider). R4/R5 passed 0/30 image screens; each other plotted round passed 30/30.", fontsize=9, color=MUTED)
    fig.text(0.075, 0.064, "R9/R18 stopped after image-screen failures. Startup failures, diagnostics and operator probes are excluded. All targets remain unmet; final ABBA is incomplete.", fontsize=9, color=MUTED)
    fig.text(0.075, 0.026, f"Source: github.com/InferMatrixLab/InferRSI/pull/394 · snapshot {SHA[:7]}  ·  2026-11-12  ·  All raw timing samples: curve-data.csv", fontsize=9, color=MUTED)
    save(fig, "iteration_comparison")


def write_data():
    with (ROOT / "curve-data.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    comparison = []
    for i, arms in enumerate(round_metrics):
        for w in WORKLOADS:
            a, b = arms["control"][w]["median_s"], arms["candidate"][w]["median_s"]
            comparison.append({"round": ROUNDS[i][0], "workload": w, "control_s": a,
                               "candidate_s": b, "latency_change_pct": (b/a-1)*100,
                               "quality": ROUNDS[i][5], "adopted": False})
    with (ROOT / "round-comparison.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=comparison[0].keys())
        writer.writeheader()
        writer.writerows(comparison)
    manifest = read("export-manifest.json")
    checked = 0
    for relative in sorted({r["source_path"] for r in rows} | {"plan/workload.json"}):
        assert hashlib.sha256((SOURCE / relative).read_bytes()).hexdigest() == manifest[relative], relative
        checked += 1
    validation = {"pr_head": SHA, "latency_rows": len(rows), "raw_timing_samples": len(rows)*3,
                  "source_hashes_verified_against_pr_manifest": checked,
                  "median_recalculation": "all match", "sample_count": "3 per point",
                  "targets": "all match frozen workload", "all_targets_unmet": all(r["median_s"] > r["target_s"] for r in rows),
                  "error_bars": "observed min/max, not confidence intervals",
                  "campaign_verdict": "INCONCLUSIVE"}
    (ROOT / "validation.json").write_text(json.dumps(validation, indent=2)+"\n")
    print(json.dumps(validation, indent=2))
    for w in WORKLOADS:
        a, b = stage_metrics[7][w]["median_s"], stage_metrics[8][w]["median_s"]
        print(f"Round2 {w}: {a:.4f} -> {b:.4f} s; observed reduction {(1-b/a)*100:.2f}%; ratio {a/b:.3f}x")


if __name__ == "__main__":
    write_data()
    main_curve()
    followup_curve()
